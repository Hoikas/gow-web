#ifndef __SPEEX_TYPES_H__
#define __SPEEX_TYPES_H__

/* these are filled in by configure */
typedef __int16 spx_int16_t;
typedef unsigned __int16 spx_uint16_t;
typedef __int32 spx_int32_t;
typedef unsigned __int32 spx_uint32_t;

#endif

