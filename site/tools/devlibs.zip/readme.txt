H-uru/Plasma Developer Library Bundle
Microsoft Visual Studio 2013
December 26, 2014

--------------------------
|        CONTENTS        |
--------------------------
curl----------------7.36.0
expat---------------2.1.0
freetype------------2.5.3
jpeg-turbo----------1.3.1
ogg-----------------1.3.1
OpenSSL-------------1.0.1g
opus----------------1.1
pcre----------------8.34
png-----------------1.6.10
Python--------------2.7.7
speex---------------1.2rc1
vorbis--------------1.3.4
vpx-----------------1.3.0
zlib----------------1.2.8

--------------------------
|         NOTES          |
--------------------------
With the exception of Python, all packages are compiled in Release mode
and linked statically with /MD (Multithreaded VC++ Runtime DLL).

Python is compiled with both Release and Debug Dynamic DLLs, due to
limitations imposed by Python and its headers.

Expat is built with cmake, which uses the UTF-8 API

SIMD instructions are used in some libraries
