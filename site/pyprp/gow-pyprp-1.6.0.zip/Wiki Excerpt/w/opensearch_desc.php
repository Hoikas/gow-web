<?xml version="1.0"?>
<OpenSearchDescription xmlns="http://a9.com/-/spec/opensearch/1.1/">
<ShortName>Guild of Writers Wiki (E</ShortName>
<Description>Guild of Writers Wiki (English)</Description>
<Image height="16" width="16" type="image/x-icon">http://guildofwriters.com/favicon.ico</Image>
<Url type="text/html" method="get" template="http://guildofwriters.com/w/index.php?title=Special:Search&amp;search={searchTerms}"/>
<Url type="application/x-suggestions+json" method="GET" template="http://guildofwriters.com/w/api.php?action=opensearch&amp;search={searchTerms}"/>
</OpenSearchDescription>