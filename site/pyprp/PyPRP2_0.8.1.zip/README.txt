==NOTES==
* Currently, this is only compatible with 32-bit Blender. You can safely install
  32-bit blender on 64-bit Windows.

==INSTALLATION==
* Copy the files inside the bin folder to your Blender install folder.
* Copy the PyPRP2 folder to your addons directory
  * By default, this is %APPDATA%\Blender Foundation\Blender\2.57\scripts\addons
  * It may be in a different location if you selected other options during
    Blender installation

==OVERVIEW==
* Each blender scene is mapped to a Plasma Page. Change the scene name at the
  top of the blender window to change the page name.
* Age properties are in the Blender 'World' buttons set.
  The 'Advanced' check here controls advanced panels throughout Blender
* Plasma modifiers can be added from the 'Constraints' panel

==FEATURES==
Most features are 
* Automatic vertex light baking
* Alpha vertex paint
* Multiple material layers
* Spawn points
* Lamps
* Textures
* Wireframe materials
* Kickables
* Sphere and Proxy physicals
